package dev.simplesolution.sftp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import dev.simplesolution.sftp.service.FileTransferService;
import org.springframework.util.StopWatch;

@Component
public class TestSftpFileTransfer implements CommandLineRunner {

	private StopWatch stopWatch;

	@Autowired
	private FileTransferService fileTransferService;
	
	private Logger logger = LoggerFactory.getLogger(TestSftpFileTransfer.class);

	public void TestSftpFileTransfer() {

	}

	@Override
	public void run(String... args) throws Exception {
		stopWatch = new StopWatch("t1");


		logger.info("Start download file");
		stopWatch.start("download");
		boolean isDownloaded = fileTransferService.downloadFile("./readme.txt", "./readme.txt");
		stopWatch.stop();
		logger.info("Download result: " + String.valueOf(isDownloaded));
		
		logger.info("Start upload file");
		stopWatch.start("upload");
		boolean isUploaded = fileTransferService.uploadFile("./readme.txt", "./readme2.txt");
		stopWatch.stop();
		logger.info("Upload result: " + String.valueOf(isUploaded));

		logger.info("performance: {}", stopWatch.prettyPrint());

	}

}
